-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2022 at 08:56 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel`
--

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `name` varchar(50) NOT NULL,
  `hostel_id` varchar(10) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `category` varchar(255) NOT NULL,
  `comp_desc` varchar(255) NOT NULL,
  `complain_no` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`name`, `hostel_id`, `room_no`, `contact_no`, `category`, `comp_desc`, `complain_no`) VALUES
('Arafat Khan', '108895', 'C205', '1234578945', 'Civil Maintenance', 'Painting required in room.', 67);

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `name` varchar(50) NOT NULL,
  `hostel_id` varchar(10) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `req_type` varchar(255) NOT NULL,
  `req_desc` varchar(255) NOT NULL,
  `request_no` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`name`, `hostel_id`, `room_no`, `contact_no`, `req_type`, `req_desc`, `request_no`) VALUES
('Arafat Khan', '108895', 'C205', '1236478546', 'Chair Change', 'Chair is broken.', 77),
('Habib Ullah', '108997', 'C-208', '9845787578', 'Mattress Change', 'Mattress is old.', 99);

-- --------------------------------------------------------

--
-- Table structure for table `slogin`
--

CREATE TABLE `slogin` (
  `hostel_id` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slogin`
--

INSERT INTO `slogin` (`hostel_id`, `password`) VALUES
('108895', '123456789'),
('109255', '123456'),
('108295', '987654321'),
('108996', '1597538462'),
('108997', '789456123');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `hostel_id` varchar(10) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `inst_name` varchar(255) NOT NULL,
  `course` varchar(50) NOT NULL,
  `contact_no` bigint(15) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `mother_name` varchar(50) NOT NULL,
  `gaurdian_name` varchar(50) NOT NULL,
  `guardian_phone` bigint(15) NOT NULL,
  `home_add` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `conf_pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`first_name`, `last_name`, `full_name`, `hostel_id`, `room_no`, `inst_name`, `course`, `contact_no`, `gender`, `father_name`, `mother_name`, `gaurdian_name`, `guardian_phone`, `home_add`, `email`, `password`, `conf_pass`) VALUES
('Imran', 'Farabi', 'Imran M Farabi', '108295', 'C206', 'MEFGI', 'CE', 1234578541, 'male', 'Kazi Imran', 'Mrs.Kazi', 'Kazi Imran', 1234784561, 'Chittagong, Bangladesh', 'imran45@gmail.com', '987654321', '987654321'),
('Arafat', 'Khan', 'Arafat Khan', '108895', 'C205', 'MEFGI', 'CE', 123465798, 'male', 'ABC', 'MRS.ABC', 'ABC', 789456123, 'CHITTAGONG, BANGLADESH', 'a.khaan937@gmail.com', '123456789', '123456789'),
('Raj', 'Chokrobarty', 'Raj M Chokrobarty', '108996', 'C-206', 'MEFGI', 'BBA', 9845787463, 'male', 'Ronak Chokrobarty', 'Rita Chokrobarty', 'Ronak Chokrobarty', 9874112546, 'Shylet, Bangladesh', 'raj@gmail.com', '1597538462', '1597534862'),
('Habib', 'Sarkar', 'Habib Ullah Sarkar', '108997', 'C-208', 'MEFGI', 'DIPLOMA', 9845787578, 'male', 'Bashar Sarkar', 'Sadia Sarkar', 'Bashar Sarkar', 9874117578, 'Pabna, Bangladesh', 'habib@gmail.com', '789456123', '789456123'),
('Ahmad', 'Daoud', 'Ahmad M Douad', '109255', 'C907', 'MEFGI', 'CE', 456123789, 'male', 'Ahmad', 'Saima', 'Ahmad', 412654795, 'Jableh, Syria', 'ahmad@gmail.com', '123456', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `studentlogin`
--

CREATE TABLE `studentlogin` (
  `hostel_id` int(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentlogin`
--

INSERT INTO `studentlogin` (`hostel_id`, `password`) VALUES
(108895, '142536');

-- --------------------------------------------------------

--
-- Table structure for table `userreg`
--

CREATE TABLE `userreg` (
  `name` varchar(40) DEFAULT NULL,
  `pass` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userreg`
--

INSERT INTO `userreg` (`name`, `pass`) VALUES
('ABCD', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `warden`
--

CREATE TABLE `warden` (
  `name` varchar(50) NOT NULL,
  `emp_id` varchar(10) NOT NULL,
  `post` varchar(50) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warden`
--

INSERT INTO `warden` (`name`, `emp_id`, `post`, `pass`) VALUES
('Mr. ABCDEFG', '1234', 'Junior Warden', '[shahu]');

-- --------------------------------------------------------

--
-- Table structure for table `wlogin`
--

CREATE TABLE `wlogin` (
  `emp_id` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wlogin`
--

INSERT INTO `wlogin` (`emp_id`, `password`) VALUES
('1234', 'shahu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`complain_no`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`request_no`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`hostel_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `complain_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `request_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
