/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.lang.Math.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HASNAT HOSEN ARAFAT
 */
public class request extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                    response.setContentType("text/html");  
                    PrintWriter out = response.getWriter();  
                    String fn=request.getParameter("name");
                    String hostelid=request.getParameter("hostel-id");
                    String roomno=request.getParameter("room-no");
                    String tele=request.getParameter("telephone");
                    String reqtype=request.getParameter("requesttype");
                    String req=request.getParameter("request");
                    
                    
                    
                   int rand = (int)(Math.random() * 100) + 2;
                    try{
                        Class.forName("com.mysql.jdbc.Driver");
                        Connection con=DriverManager.getConnection(
                                "jdbc:mysql://127.0.0.1:3306/hostel", "root", "");
                        
                        PreparedStatement ps=con.prepareStatement(
                                "insert into request values(?,?,?,?,?,?,?)");
                        
                        ps.setString(1,fn);
                        ps.setString(2,hostelid);
                        ps.setString(3,roomno);
                        ps.setString(4,tele);
                        ps.setString(5,reqtype);
                        ps.setString(6,req);
                        ps.setInt(7, rand);
                        
                        int i=ps.executeUpdate();

                        if(i>0)
                            out.print("Request successfully added");
                            out.println("<h1>Go to home</h1>");
                            out.println("<a href='home.html'>Home"
                                    + "<img border='0' src='Home.jpg' alt='Back' width='100' height='100' ></a>");
                            out.println("<a href='student.jsp'>Go Back"
                                    + "<img border='0' src='back.jpg' alt='Back' width='100' height='100' ></a>");
                            
                        
                        
                    }catch (Exception e2) {System.out.println(e2);}
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
