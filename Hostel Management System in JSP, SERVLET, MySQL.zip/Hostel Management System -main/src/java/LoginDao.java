import java.sql.*;  
public class LoginDao
{  
     public static boolean validate(String id ,String pass)
     {  
          boolean status=false;
          try
          {  
               Class.forName("com.mysql.jdbc.Driver");  
               Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/hostel", "root", "");  
      
               PreparedStatement ps=con.prepareStatement(  
               "select * from slogin where hostel_id = ? and password = ?");
               
               //int hid = Integer.parseInt("id");
               //int password = Integer.parseInt("pass");
               
               ps.setString(1,id);  
               ps.setString(2,pass); 
               
               ResultSet rs=ps.executeQuery();  
               status=rs.next();  
          }
          catch(ClassNotFoundException | NumberFormatException | SQLException e)
          {
               System.out.println(e);
          }  
          return status;  
     }  
}
